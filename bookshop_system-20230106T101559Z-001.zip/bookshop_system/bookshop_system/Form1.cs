﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookshop_system
{
    public partial class frmwelcome : Form
    {
        public frmwelcome()
        {
            InitializeComponent();
        }

        private void btncontinue_Click(object sender, EventArgs e)
        {
            frmlogin login = new frmlogin();
            login.Show();
            this.Hide();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            DialogResult ans = MessageBox.Show("Are You Sure to Close the Application?", "connformation for close", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(ans==DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
