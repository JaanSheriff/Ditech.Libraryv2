﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bookshop_system
{
    public partial class frmaddbook : Form
    {
        //declare an object for connection
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\user\Desktop\bookshop project\Project_final\bookshop_system\bookshop_system\bookdetails.mdf;Integrated Security=True");

        //declare an object for command/messenger
        SqlCommand com;
        public frmaddbook()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            frmmenu menu = new frmmenu();
            menu.Show();
            this.Hide();
        }

        private void btnaddbook_Click(object sender, EventArgs e)
        {
            con.Open();
            string sqlinsert = "insert into book(bookcode,title,author,languagecode,rackna,price,quantity)values('" + txtbookcode.Text + "','" + txttitle.Text + "','" + txtauthor.Text + "','" + txtlanguage.Text + "','" + txtrack.Text + "','" + txtprice.Text + "','" + txtquautity.Text + "')";
            
            //send the message
            com = new SqlCommand(sqlinsert, con);
            //execute the sqlstatement
            com.ExecuteNonQuery();

            //display the message
            MessageBox.Show("Record is added sucessfully");

            //close the database
            con.Close();
            txtbookcode.Clear();
            txttitle.Clear();
            txtauthor.Clear();
            txtlanguage.Clear();
            txtrack.Clear();
            txtprice.Clear();
            txtquautity.Clear();
            txtbookcode.Focus();
                
               

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtbookcode.Clear();
            txttitle.Clear();
            txtauthor.Clear();
            txtlanguage.Clear();
            txtrack.Clear();
            txtprice.Clear();
            txtquautity.Clear();
            txtbookcode.Focus();
        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqlsearch="select * from book where bookcode='"+txtbookcode.Text+"'";
                com = new SqlCommand(sqlsearch, con);
                SqlDataReader dr = com.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("Duplicate Book Code");
                    txtbookcode.Clear();
                    txtbookcode.Focus();
                }
                else
                {
                    txttitle.Focus();
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
