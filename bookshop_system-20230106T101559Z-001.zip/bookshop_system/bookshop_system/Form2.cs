﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookshop_system
{
    public partial class frmlogin : Form
    {
        public frmlogin()
        {
            InitializeComponent();
        }

        private void gbuserlogin_Enter(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string username = "staff";
            string password = "123@bookshop";
            if(txtusername.Text==username && txtpassword.Text==password)
            {
                frmmenu menu = new frmmenu();
                menu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invaild Details-Enter again","Login Permission",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtusername.Clear();
                txtpassword.Clear();
                txtusername.Focus();
            }

        }
    }
}
