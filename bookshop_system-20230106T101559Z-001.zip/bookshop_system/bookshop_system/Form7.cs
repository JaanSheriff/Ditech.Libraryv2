﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace bookshop_system
{
    public partial class frmcalculation : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\user\Desktop\bookshop project\Project_final\bookshop_system\bookshop_system\bookdetails.mdf;Integrated Security=True");
        SqlCommand com;
        public frmcalculation()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            frmmenu menu = new frmmenu();
            menu.Show();
            this.Hide();
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtbookcode.Clear();
            txttitle.Clear();
            txtprice.Clear();
            txtquautity.Clear();
            txtbooksold.Clear();
            txtpayment.Clear();
            txtbookcode.Focus();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            con.Open();
            string sqlsearch = "select* from book where bookcode ='" + txtbookcode.Text + "'";
            com = new SqlCommand(sqlsearch, con);
            SqlDataReader dr = com.ExecuteReader();
            if(dr.Read())
            {
                txttitle.Text = dr["title"].ToString();
                txtprice.Text = dr["price"].ToString();
                txtquautity.Text = dr["quantity"].ToString();
                txtbooksold.Focus();
                
                
            }
            else
            {
                MessageBox.Show("Record is not found");
                txtbookcode.Clear();
                txtbookcode.Focus();
            }
            con.Close();

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            int qty, sold, balance;
            qty = int.Parse(txtquautity.Text);
            sold = int.Parse(txtbooksold.Text);
            balance = qty - sold;

            con.Open();
            string sqlupdate = "update book set quantity='" + balance+ "'where bookcode = '"+txtbookcode.Text+"'";
            com = new SqlCommand(sqlupdate, con);
            com.ExecuteNonQuery();
            MessageBox.Show("updated successfully");
            con.Close();
        }

        private void btncalculate_Click(object sender, EventArgs e)
        {
            int price, booksold, payment;
            price = int.Parse(txtprice.Text);
            booksold = int.Parse(txtbooksold.Text);
            
            payment = price * booksold;
            txtpayment.Text = payment.ToString();

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }
    }
}
