﻿namespace bookshop_system
{
    partial class frmsearchbook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnback = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.btndisplayall = new System.Windows.Forms.Button();
            this.dgvdisplay = new System.Windows.Forms.DataGridView();
            this.cblanguage = new System.Windows.Forms.ComboBox();
            this.txtbookcode = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvdisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Black;
            this.btnback.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.White;
            this.btnback.Location = new System.Drawing.Point(865, 621);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(246, 78);
            this.btnback.TabIndex = 15;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.Black;
            this.btnreset.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreset.ForeColor = System.Drawing.Color.White;
            this.btnreset.Location = new System.Drawing.Point(538, 621);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(246, 78);
            this.btnreset.TabIndex = 14;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btndisplayall
            // 
            this.btndisplayall.BackColor = System.Drawing.Color.Black;
            this.btndisplayall.Font = new System.Drawing.Font("Bookman Old Style", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndisplayall.ForeColor = System.Drawing.Color.White;
            this.btndisplayall.Location = new System.Drawing.Point(211, 621);
            this.btndisplayall.Name = "btndisplayall";
            this.btndisplayall.Size = new System.Drawing.Size(246, 78);
            this.btndisplayall.TabIndex = 13;
            this.btndisplayall.Text = "Display All";
            this.btndisplayall.UseVisualStyleBackColor = false;
            this.btndisplayall.Click += new System.EventHandler(this.btndisplayall_Click);
            // 
            // dgvdisplay
            // 
            this.dgvdisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvdisplay.Location = new System.Drawing.Point(211, 180);
            this.dgvdisplay.Name = "dgvdisplay";
            this.dgvdisplay.RowTemplate.Height = 24;
            this.dgvdisplay.Size = new System.Drawing.Size(900, 389);
            this.dgvdisplay.TabIndex = 12;
            this.dgvdisplay.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvgisplay_CellContentClick);
            // 
            // cblanguage
            // 
            this.cblanguage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cblanguage.FormattingEnabled = true;
            this.cblanguage.Location = new System.Drawing.Point(918, 71);
            this.cblanguage.Name = "cblanguage";
            this.cblanguage.Size = new System.Drawing.Size(145, 33);
            this.cblanguage.TabIndex = 11;
            this.cblanguage.SelectedIndexChanged += new System.EventHandler(this.cblanguage_SelectedIndexChanged);
            // 
            // txtbookcode
            // 
            this.txtbookcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbookcode.Location = new System.Drawing.Point(444, 74);
            this.txtbookcode.Name = "txtbookcode";
            this.txtbookcode.Size = new System.Drawing.Size(141, 30);
            this.txtbookcode.TabIndex = 10;
            this.txtbookcode.TextChanged += new System.EventHandler(this.txtbookcode_TextChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Black;
            this.Label2.Font = new System.Drawing.Font("Copperplate Gothic Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.White;
            this.Label2.Location = new System.Drawing.Point(699, 81);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(153, 26);
            this.Label2.TabIndex = 9;
            this.Label2.Text = "Language ";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.BackColor = System.Drawing.Color.Black;
            this.Label1.Font = new System.Drawing.Font("Copperplate Gothic Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.White;
            this.Label1.Location = new System.Drawing.Point(234, 81);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(153, 26);
            this.Label1.TabIndex = 8;
            this.Label1.Text = "Book code";
            // 
            // frmsearchbook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::bookshop_system.Properties.Resources.f6c6576ad411dc2cd3fa7af55f26b3dd_2_;
            this.ClientSize = new System.Drawing.Size(1322, 770);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btndisplayall);
            this.Controls.Add(this.dgvdisplay);
            this.Controls.Add(this.cblanguage);
            this.Controls.Add(this.txtbookcode);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Name = "frmsearchbook";
            this.Text = "Search Book";
            this.Load += new System.EventHandler(this.frmsearchbook_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvdisplay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnback;
        internal System.Windows.Forms.Button btnreset;
        internal System.Windows.Forms.Button btndisplayall;
        internal System.Windows.Forms.DataGridView dgvdisplay;
        internal System.Windows.Forms.ComboBox cblanguage;
        internal System.Windows.Forms.TextBox txtbookcode;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
    }
}