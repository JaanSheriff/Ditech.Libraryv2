﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace bookshop_system
{
    public partial class frmsearchbook : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\user\Desktop\bookshop project\Project_final\bookshop_system\bookshop_system\bookdetails.mdf;Integrated Security=True");
        SqlCommand com;
        public frmsearchbook()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            frmmenu menu=new frmmenu();
            menu.Show();
            this.Hide();
        }

        private void btndisplayall_Click(object sender, EventArgs e)
        {
            con.Open();
            string sqlselect = "select * from book";
            com = new SqlCommand(sqlselect, con);
            SqlDataReader dr = com.ExecuteReader();
            // declare an object of the database class
            DataTable dt = new DataTable();
            //move the data from dr to dt
            dt.Load(dr);
            //move the data from dt to dvg
            dgvdisplay.DataSource = dt;
            con.Close();


        }

        private void dgvgisplay_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtbookcode_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sql = "select * from book where bookcode='" + txtbookcode.Text + "'";
                com = new SqlCommand(sql, con);
                SqlDataReader dr;
                dr = com.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                dgvdisplay.DataSource = dt;
                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
            
        }
            
        private void btnreset_Click(object sender, EventArgs e)
        {
            dgvdisplay.DataSource = null;
            txtbookcode.Clear();
            txtbookcode.Focus();
        }

        private void cblanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
            try
            {
                con.Open();
                string sql = "select * from book where languagecode='" + cblanguage.Text + "'";
                com = new SqlCommand(sql, con);
                SqlDataReader dr;
                dr = com.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dr);
                dgvdisplay.DataSource = dt;
                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                con.Close();
            }
            
        }

        private void frmsearchbook_Load(object sender, EventArgs e)
        {
            cblanguage.Items.Add("English");
            cblanguage.Items.Add("Tamil");
            cblanguage.Items.Add("Sinhala");
        }

        }

        
 }

