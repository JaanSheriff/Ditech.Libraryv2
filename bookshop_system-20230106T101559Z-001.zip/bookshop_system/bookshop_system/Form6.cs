﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bookshop_system
{
    public partial class frmeditdeletebook : Form
    {
        //declare object for connection
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\user\Desktop\bookshop project\Project_final\bookshop_system\bookshop_system\bookdetails.mdf;Integrated Security=True");

        //declare on object for command or messenger
        SqlCommand com;

        public frmeditdeletebook()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            frmmenu menu = new frmmenu();
            menu.Show();
            this.Hide();

        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            //open the database using by the connection object 
            con.Open();

            //declare a string variable to hold the sqlstatement
            string sqlsearch = "select * from book where bookcode='" + txtbookcode.Text + "'";

            //send the message through com
            com = new SqlCommand(sqlsearch, con);

            //execute the sqlstatement and store the result in the object dr
            SqlDataReader dr = com.ExecuteReader();

            //check the record availability
            if(dr.Read())//record exists
            {
                //display the other fields
                txttitle.Text = dr["title"].ToString();
                txtauthor.Text = dr["author"].ToString();
                txtlanguage.Text = dr["languagecode"].ToString();
                txtrackno.Text = dr["rackna"].ToString();
                txtprice.Text = dr["price"].ToString();
                txtquautity.Text = dr["quantity"].ToString();

            }
            else
            {
                MessageBox.Show("Record is not found");
                txtbookcode.Clear();
                txtbookcode.Focus();
            }
            con.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string sqlupdate = "update book set title='"+txttitle.Text+"',author='"+txtauthor.Text+"',languagecode='"+txtlanguage.Text+"',rackna='"+txtrackno.Text+"',price='"+txtprice.Text+"',quantity='"+txtquautity.Text+"' where bookcode='"+txtbookcode.Text+"'";
                com = new SqlCommand(sqlupdate, con);
                com.ExecuteNonQuery();
                MessageBox.Show("Saved successfully");
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            con.Open();
            DialogResult ans = MessageBox.Show("Are You Sure to delete now?","conformation for delete",MessageBoxButtons.YesNo,MessageBoxIcon.Question );
            if (ans==DialogResult.Yes)
            {
                string sqldelete = "delete from book where bookcode='" + txtbookcode.Text + "'";
                com = new SqlCommand(sqldelete, con);
                com.ExecuteNonQuery();
                MessageBox.Show("Record is deleted successfully");

            }
            con.Close();

        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtbookcode.Clear();
            txttitle.Clear();
            txtauthor.Clear();
            txtlanguage.Clear();
            txtrackno.Clear();
            txtprice.Clear();
            txtquautity.Clear();
            txtbookcode.Focus();
        }

        private void frmeditdeletebook_Load(object sender, EventArgs e)
        {

        }
    }
}
