﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookshop_system
{
    public partial class frmmenu : Form
    {
       
        public frmmenu()
        {
            InitializeComponent();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            frmsearchbook searchbook = new frmsearchbook();
            searchbook.Show();
            this.Hide();
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            frmaddbook addbook = new frmaddbook();
            addbook.Show();
            this.Hide();
        }

        private void btneditdelete_Click(object sender, EventArgs e)
        {
            frmeditdeletebook editdelete = new frmeditdeletebook();
            editdelete.Show();
            this.Hide();

        }

        private void btncalculate_Click(object sender, EventArgs e)
        {
            frmcalculation calculation = new frmcalculation();
            calculation.Show();
            this.Hide();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
           
            DialogResult ans = MessageBox.Show("Are You Sure to Exit?", "conformation to Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(ans==DialogResult.Yes)
              
            {
                Application.Exit();
                

            }
            
        }

        private void frmmenu_Load(object sender, EventArgs e)
        {

        }
    }
}
